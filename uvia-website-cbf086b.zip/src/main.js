import './styles.css';

const logo = '/manus-storage/UVIAlogo(500x500px)_24e5f407.png';
const principals = [
  ['Country Bankers Insurance Group', '/manus-storage/country-bankers-insurance-group_b0119a13.webp'],
  ['A Insurance', '/manus-storage/a-insurance_e148a183.webp'],
  ['Oona Insurance', '/manus-storage/ona-insurance_4cbe8d31.webp'],
  ['Standard Insurance', '/manus-storage/standard-insurance_a1203483.webp'],
  ['Bethel', '/manus-storage/bethel_8a40a166.webp'],
  ['FGen Insurance', '/manus-storage/fgen-insurance_13e130fe.webp']
];
const partners = [
  ['Forbes Credit Financing', '/manus-storage/forbes-credit-financing_af841f17.webp'],
  ['AutoAllee Centris', '/manus-storage/autoallee-centris_fc1e7b46.webp'],
  ['Auto Express', '/manus-storage/auto-express_fa51352a.webp'],
  ['Ford Otis Manila', '/manus-storage/ford-otis-manila_13ecc3b2.webp'],
  ['BK Garage', '/manus-storage/bk-garage_5281deeb.webp'],
  ['Auto Guard Pro', '/manus-storage/auto-guard-pro_d9ca8510.webp'],
  ['MG Commonwealth', '/manus-storage/mg-commonwealth_a4e75191.webp'],
  ['Forbes Council', '/manus-storage/forbes-council_51d8ce32.webp'],
  ['CartGo MNL', '/manus-storage/cartgo-mnl_1d560e35.webp'],
  ['Global Dominion', '/manus-storage/global-dominion_0a72b1d5.webp'],
  ['Car Rental', '/manus-storage/car-rental_b42f3f53.webp'],
  ['ITL The Commercial', '/manus-storage/itl-the-commercial_8f06e95a.webp'],
  ['Geely Marikina Fairview', '/manus-storage/geely-marikina-fairview_df0333c5.webp'],
  ['UGC Car Manila', '/manus-storage/ugc-car-manila_a63832ea.webp'],
  ['South Asialink Finance', '/manus-storage/south-asialink-finance_1f402ddd.webp'],
  ['Throttle Collection', '/manus-storage/throttle-collection_91666397.webp'],
  ['Cycle', '/manus-storage/cycle_cd35228f.webp'],
  ['Asialink Finance', '/manus-storage/asialink-finance_a450fa05.webp'],
  ['Security Bank', '/manus-storage/security-bank_aea3b695.webp'],
  ['EastWest', '/manus-storage/eastwest_6e022fcf.webp'],
  ['Autosan', '/manus-storage/autosan_ce27720d.webp']
];

document.querySelector('#app').innerHTML = `
  <header class="site-header" id="top">
    <a class="brand" href="#top" aria-label="Uni-Vanguard Insurance Agency home">
      <span class="brand-mark"><img src="${logo}" alt="Uni-Vanguard shield logo" /></span>
      <span class="brand-copy"><strong>UNI-VANGUARD</strong><small>INSURANCE AGENCY INC.</small></span>
    </a>
    <button class="menu-toggle" type="button" aria-expanded="false" aria-controls="main-nav"><span></span><span></span><span></span><b class="sr-only">Menu</b></button>
    <nav id="main-nav" class="main-nav" aria-label="Main navigation">
      <a href="#about">About us</a>
      <a href="#offer">What we offer</a>
      <a href="#locations">Branches</a>
      <a href="#partners">Partners</a>
      <a href="#different">What makes us different</a>
      <a class="nav-cta" href="#contact">Contact us <span aria-hidden="true">↗</span></a>
    </nav>
  </header>

  <main>
    <section class="hero section-pad">
      <div class="hero-meta eyebrow"><span>UNI-VANGUARD / 01</span><span>INSURANCE SOLUTIONS</span></div>
      <div class="hero-grid">
        <div class="hero-copy reveal">
          <p class="kicker">COMPANY VISION</p>
          <h1>To be the Philippines’ most trusted and <em>forward-thinking</em> insurance leader.</h1>
          <div class="hero-bottom"><p class="hero-lede">Scaling from an agency to a broker to a full-scale insurance provider, redefining protection through innovative, tailored solutions that empower individuals and businesses to thrive with confidence in an ever-changing world.</p><a class="button button-red" href="#contact">Contact us <span aria-hidden="true">↗</span></a></div>
        </div>
      </div>
      <div class="hero-rule"><span>01</span><span>OUR CULTURE. OUR VALUES. OUR COMMITMENT.</span><span>↓</span></div>
    </section>

    <section class="feature-rail section-pad" aria-label="Uni-Vanguard highlights">
      <article class="rail-card rail-dark reveal"><span class="rail-icon">◩</span><h3>What do we offer?</h3><p>Insurance solutions and personalized services that safeguard our clients’ financial security.</p><a href="#offer">Explore insurance <span aria-hidden="true">↗</span></a></article>
      <article class="rail-card rail-red reveal reveal-delay"><span class="rail-icon">✦</span><h3>Our promise</h3><p>A promise to protect. A promise to act. A promise to stand firm for every client we serve.</p><a href="#promise">Read our promise <span aria-hidden="true">↗</span></a></article>
      <div class="rail-emblem reveal"><div class="rail-emblem-inner"><img src="/manus-storage/pasted_file_NxFUKR_image_9f41a00f.png" alt="Building exterior" /></div><span>SELECTED VISUAL / UNI-VANGUARD</span></div>
      <article class="rail-card rail-dark rail-testimonial reveal reveal-delay"><span class="rail-icon">◌</span><p class="quote">“We are an operating system for protection.”</p><small>THE CORE STATEMENT<br />UNI-VANGUARD</small></article>
    </section>

    <section class="promise-strip" id="promise">
      <div class="section-pad promise-grid reveal">
        <div><span class="section-number">02 / OUR PROMISE</span><h2>The VanguardShield is more than a logo — it is a promise.</h2></div>
        <div class="promise-list"><p>A promise to <strong>protect.</strong></p><p>A promise to <strong>act.</strong></p><p>A promise to <strong>stand firm</strong> for every client we serve.</p></div>
      </div>
    </section>

    <section class="intro section-pad" id="about">
      <div class="section-heading reveal"><span class="section-number">03 / ABOUT US</span><h2>A financially stable entity with a broad network and a commitment to accessible service.</h2></div>
      <div class="intro-grid">
        <div class="intro-stamp reveal"><span>EST.</span><strong>2019</strong><span>PHILIPPINES</span></div>
        <div class="intro-copy reveal reveal-delay">
          <p>Vanguard Guarantee Insurance Consultancy Inc. was founded in 2019 but will not open its doors until June 2022 as a solely owned Filipino non-life insurance services company.</p>
          <p>Uni-Vanguard Insurance Agency Inc. takes pride of its accomplishment to where it is now by being a financially stable entity. Proof of this is the steady growth of its net-worth over the years of its operation.</p>
          <div class="value-row"><span>C</span><div><strong>Collaboration</strong><small>COMPANY CORE VALUE</small></div><span>I</span><div><strong>Integrity</strong><small>COMPANY CORE VALUE</small></div><span>A</span><div><strong>Adaptability</strong><small>COMPANY CORE VALUE</small></div></div>
        </div>
      </div>
    </section>

    <section class="offer section-pad" id="offer">
      <div class="section-heading section-heading-light reveal"><span class="section-number">04 / WHAT DO WE OFFER?</span><h2>Our insurance.</h2></div>
      <div class="product-grid">
        ${['CAR INSURANCE','MOTORCYCLE INSURANCE','PERSONAL ACCIDENT INSURANCE','TRAVEL INSURANCE','MARINE INSURANCE','CTPL','SECURITY GUARD PERSONAL ACCIDENT INSURANCE','PET INSURANCE','GADGET INSURANCE','BONDS'].map((item, index) => `<article class="product-card reveal" style="--i:${index}"><span class="product-index">0${index + 1}</span><h3>${item}</h3><span class="product-arrow" aria-hidden="true">↗</span></article>`).join('')}
      </div>
    </section>

    <section class="locations section-pad" id="locations">
      <div class="section-heading reveal"><span class="section-number">05 / OUR BRANCHES &amp; SALES HUB</span><h2>Find Uni-Vanguard where you are.</h2></div>
      <div class="location-grid">
        <article class="location-card reveal"><span class="location-index">01 / BRANCH</span><h3>Tarlac Branch</h3><p>Unit 4, D&amp;F Commercial Building, Zone 4, Maliwalo, Tarlac City, Tarlac, Philippines, 2300</p><a class="text-link" href="https://www.google.com/maps/search/?api=1&amp;query=Unit+4+D%26F+Commercial+Building+Zone+4+Maliwalo+Tarlac+City+Tarlac+Philippines+2300" target="_blank" rel="noreferrer">Open map <span aria-hidden="true">↗</span></a></article>
        <article class="location-card reveal reveal-delay"><span class="location-index">02 / BRANCH</span><h3>Nueva Ecija Branch</h3><p>Maharlika Hiway, Barangay Valenzuela, Santa Rosa, Cabanatuan, Nueva Ecija</p><a class="text-link" href="https://www.google.com/maps/search/?api=1&amp;query=Maharlika+Hiway+Barangay+Valenzuela+Santa+Rosa+Cabanatuan+Nueva+Ecija" target="_blank" rel="noreferrer">Open map <span aria-hidden="true">↗</span></a></article>
        <article class="location-card location-accent reveal"><span class="location-index">03 / SALES HUB</span><h3>Kawit Sales Hub</h3><p>Advincula Avenue, beside M.O Rieta Bldg., San Sebastian, Kawit, Philippines, 4194<br /><small>Pin: Euro Oil Kawit</small></p><a class="text-link" href="https://www.google.com/maps/search/?api=1&amp;query=Advincula+Avenue+San+Sebastian+Kawit+Philippines+4194" target="_blank" rel="noreferrer">Open map <span aria-hidden="true">↗</span></a></article>
      </div>
      <p class="upcoming-note">UPCOMING : Imus, Amadeo &amp; BGC</p>
    </section>

    <section class="principals section-pad" id="principals">
      <div class="section-heading section-heading-light reveal"><span class="section-number">06 / OUR INSURANCE PRINCIPALS</span><h2>Insurance principals, presented with clarity.</h2></div>
      <div class="principal-grid">${principals.map(([name, image], index) => `<article class="principal-card reveal" style="--i:${index}"><div class="principal-logo"><img src="${image}" alt="${name} logo" /></div><span class="location-index">INSURANCE PRINCIPAL / 0${index + 1}</span><h3>${name}</h3></article>`).join('')}</div>
    </section>

    <section class="partners section-pad" id="partners">
      <div class="section-heading reveal"><span class="section-number">07 / KEY PARTNERS</span><h2>Professional relationships across the network.</h2></div>
      <div class="partner-grid">${partners.map(([name, image], index) => `<article class="partner-card reveal" style="--i:${index}"><div class="partner-logo"><img src="${image}" alt="${name} logo" /></div><div><span class="location-index">KEY PARTNER / ${String(index + 1).padStart(2, '0')}</span><h3>${name}</h3></div></article>`).join('')}</div>
    </section>

    <section class="different section-pad" id="different">
      <div class="different-top reveal"><span class="section-number">08 / WHAT MAKES US DIFFERENT</span><div class="accent-line"></div><h2>We own the <em>outcome.</em></h2></div>
      <div class="outcome-grid">
        <article class="outcome-card reveal"><span class="outcome-number">01</span><h3>We Own the Outcome</h3><p>When a client buys from Vanguard, the responsibility doesn’t shift to a provider, a hotline, or a third party. It stays with us.</p><p class="outcome-note">If there’s a claim, a delay, or confusion — we don’t say “coordinate with…” we say “we’ll handle it.”</p></article>
        <article class="outcome-card dark-card reveal reveal-delay"><span class="outcome-number">02</span><h3>We Are Built For the Worst Day, Not The Best Day</h3><p>Uni-Vanguard is designed for accidents, claims, disputes, delays, stress, and urgency.</p><p class="outcome-note">24/7 Customer Service / The Support Command Center · 24/7 Claims Command Center</p></article>
        <article class="outcome-card red-card reveal"><span class="outcome-number">03</span><h3>We Replace Uncertainty With Systems</h3><p>Every inquiry, claim, renewal, and escalation is tracked, timed, and owned. That’s how trust is engineered—not advertised.</p></article>
        <article class="outcome-card outline-card reveal reveal-delay"><span class="outcome-number">04</span><h3>We Replace Emotional Cost of Insurance</h3><p>The real cost of insurance isn’t the premium. It’s time wasted, stress, being passed around, and not knowing who’s responsible.</p></article>
      </div>
    </section>

    <section class="core-statement">
      <div class="section-pad core-inner reveal"><span class="section-number">09 / THE CORE STATEMENT</span><blockquote>“Uni-Vanguard is not an insurance seller.<br /><em>We are an operating system for protection.</em>”</blockquote><span class="core-mark">UVIA</span></div>
    </section>

    <section class="contact section-pad" id="contact">
      <div class="contact-grid reveal">
        <div><span class="section-number">10 / CONTACT US</span><h2>Exceptional insurance solutions.<br /><em>Personalized services.</em></h2><a class="button button-red" href="tel:09458438947">Contact us <span aria-hidden="true">↗</span></a></div>
        <div class="contact-details"><div><small>PHONE</small><p>0945 843 8947 / 840 34939</p></div><div><small>EMAIL</small><p><a class="email-link" href="mailto:inquiry.sales@vanguardguaranteeinsurance.com">inquiry.sales@vanguardguaranteeinsurance,com</a></p></div><div><small>WEBSITE</small><p>www.vanguardguaranteeinsurance.com</p></div><div><small>ADDRESS</small><p>5th Floor, Unit 503-505, One Rebtrade Building, 380 Quirino Highway, Greater Lagro, Quezon City, 1100 Metro Manila</p></div></div>
      </div>
    </section>
  </main>

  <footer class="site-footer"><div class="section-pad footer-inner"><a class="brand footer-brand" href="#top"><span class="brand-mark"><img src="${logo}" alt="Uni-Vanguard shield logo" /></span><span class="brand-copy"><strong>UNI-VANGUARD</strong><small>INSURANCE AGENCY INC.</small></span></a><div class="footer-links"><a href="#about">About us</a><a href="#offer">What we offer</a><a href="#locations">Branches</a><a href="#partners">Partners</a><a href="#contact">Contact us</a></div><div class="footer-social">vanguardinsuranceservicesofficial<br /><span>© Uni-Vanguard Insurance Agency Inc.</span></div></div></footer>
`;

const menuButton = document.querySelector('.menu-toggle');
const nav = document.querySelector('.main-nav');
menuButton.addEventListener('click', () => {
  const open = menuButton.getAttribute('aria-expanded') === 'true';
  menuButton.setAttribute('aria-expanded', String(!open));
  nav.classList.toggle('is-open', !open);
});
nav.querySelectorAll('a').forEach((link) => link.addEventListener('click', () => {
  menuButton.setAttribute('aria-expanded', 'false');
  nav.classList.remove('is-open');
}));

const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
if (!reduceMotion && 'IntersectionObserver' in window) {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) { entry.target.classList.add('is-visible'); observer.unobserve(entry.target); }
    });
  }, { threshold: 0.12 });
  document.querySelectorAll('.reveal').forEach((element) => observer.observe(element));
} else {
  document.querySelectorAll('.reveal').forEach((element) => element.classList.add('is-visible'));
}
