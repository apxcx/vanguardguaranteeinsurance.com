# Delivery outcomes

## Responsive branded shell
- [ ] Feature the supplied UVIA company logo prominently in the header/navigation bar and footer.
- [ ] Use clean whites/off-whites and dark grays/blacks for high-contrast neutrals, with #f53430 replacing the reference screenshot’s blue accent.
- [ ] Ensure fully responsive mobile, tablet, and desktop views with semantic typography hierarchy, generous whitespace, accessible contrast, and fluid layouts.

## Approved-content landing page
- [ ] Use only the copy, text sections, headlines, and structural messaging provided in UVIACompanyProfileProductsandServices.pdf.
- [ ] Include a hero section with an H1, supporting copy, and conversion-focused CTA using only messaging extracted from the supplied PDF.
- [ ] Include company introduction and credibility content based exclusively on the supplied PDF.
- [ ] Present the products and services in a responsive card or grid layout with H3 sub-feature headings.
- [ ] Arrange supporting content sections to match the reference screenshot’s section flow, spacing, and grid structure without copying its imagery or colors.
- [ ] Include high-visibility CTA sections using #f53430 to guide visitors toward contacting or engaging Uni-Vanguard.
- [ ] Include a responsive footer with the supplied UVIA logo and only company details or messaging available in the supplied PDF.

## Interaction and delivery
- [ ] Provide a responsive navigation menu and working in-page CTA links.
- [ ] Provide the required static route manifest at GET /manus-routes.json.
- [ ] Verify the project build and preview rendering before checkpointing.
